# CI / CD Strategy with Docker

## Test Java APP locally
```bash
$ git clone https://github.com/contreras-adr/training-java-hello-world.git
$ cd training-java-hello-world
$ docker build -t scalian_training-java-hello-world:0.0.1 -f java_app/devops/dev.Dockerfile java_app
$ docker run -d --rm -p 8084:8080  --name java-app   scalian_training-java-hello-world:0.0.1
$ curl localhost:8084/hello
$ docker stop java-app
$ cd ..
```

## Recreate services
```bash
$ docker compose up -d --force-recreate
```